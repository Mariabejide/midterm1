<template>
  <div class="container">
    <h1>Welcome to Maria's Weather App</h1>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <router-link class="navbar-brand" to="/">Home</router-link>
        <router-link class="navbar-brand" to="/form">Form</router-link>
      </div>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'HomeView'
}
</script>

<style>
/* Home view styles */
</style>
