<template>
  <div class="home">
    <h1>Welcome to the Weather App</h1>
    <nav>
      <ul>
        <li><router-link to="/">Home</router-link></li>
        <li><router-link to="/form">Form</router-link></li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'HomeView'
}
</script>
